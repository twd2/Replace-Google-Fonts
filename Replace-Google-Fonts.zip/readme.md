Replace Google Fonts
====================

Contributors: soulteary

Tags: Google Fonts, Google Web Fonts, GFW mirror

Requires at least: 3.5

Tested up to: 4.0

Stable tag: 1.0

Use alternative open fonts service mirror in mainland to replace Google's.

TODO: add a option page in dashboard that allows user manually switch font source.

Description
===========

[Plugin homepage](http://www.soulteary.com/2014/06/08/) | [Plugin author](http://www.soulteary.com/)

Forked from [ChiChou/Replace-Google-Fontss](https://github.com/ChiChou/Replace-Google-Fontss).

Forked from [soulteary/Replace-Google-fonts](https://github.com/soulteary/Replace-Google-Fonts), use USTC source for personal flavor.

Installation
============

1. Upload `replace-google-fonts` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

or
--

1. Upload the plugin(Replace-Google-Fonts.zip) through the 'Plugins' menu in WordPress
